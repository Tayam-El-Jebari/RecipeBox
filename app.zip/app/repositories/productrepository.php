<?php
require __DIR__ . '/repository.php';
require __DIR__ . '/../models/mealProduct.php';

class ProductRepository extends Repository {

    function getMostRecentFive() {
        try {
            $stmt = $this->connection->query("SELECT meals.*, GROUP_CONCAT(ingredients.ingredient) as ingredients, GROUP_CONCAT(ingredients.ingredientWeight) as ingredientsWeight
            FROM meals 
            INNER JOIN ingredients 
            ON meals.id = ingredients.meal_id 
            GROUP BY meals.id 
            ORDER BY meals.id DESC LIMIT 5;");

            $products = array();

            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $product = new MealProduct();
                $product->setProductId($row['id']);
                $product->setMainIngredient($row['mainIngedientId']);
                $product->setPrice($row['Price']);
                $product->setImageAddress($row['image']);
                $product->setProductName($row['name']);
                $product->setKcal($row['kcal']);
                $product->setAllergens($row['allergens']);
                $product->setIngredients($row['ingredients']);
                $product->setIngredients($row['ingredientsWeight']);
                $products[] = $product;
            }
            
            return $products;

        } catch (PDOException $e)
        {
            echo $e;
        }
    }
}