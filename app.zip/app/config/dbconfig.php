<?php
$type = "mysql";
$servername = "mysql";
$username = "root";
$password = "secret123";
$database = "developmentdb";
