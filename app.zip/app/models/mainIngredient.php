<?php
enum MainIngredient:int
{
    
    case kip = 0;
    case rundvlees = 1;
    case vis = 2;
    case vega = 3;
}