<?php
require __DIR__ . '/../repositories/productrepository.php';

class ProductService {
    public function getMostRecentFive() {

        $repository = new ProductRepository();
        return $repository->getMostRecentFive();
    }
}