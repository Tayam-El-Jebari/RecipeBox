<?php
require __DIR__ . '/../services/productservice.php';

class ProductController
{
    private $productService;

    function __construct()
    {
        $this->productService = new ProductService();
    }

    public function getMostRecentFive()
    {    
        return $this->productService->getMostRecentFive();
    }
}