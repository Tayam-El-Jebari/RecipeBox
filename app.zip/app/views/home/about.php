<?php
include __DIR__ . '/../header.php';

echo "<h1>About page!</h1>";

include __DIR__ . '/../footer.php';
