<?php

include __DIR__ . '/../header.php';
require __DIR__ . '/../../controllers/productcontroller.php';


?>
<!DOCTYPE html>
<html lang="en">

<body>

<div class="banners container px-4 px-lg-5 my-5">
  <div class="row">
    <div class="col-md-7">
      <div class="text-left text-dark">
        <h1 class="display-4 fw-bolder">Recipe Box</h1>
        <h1 class="display-4 fw-bolder">Recipe Box</h1>
        <div class="container">
        <img src="/img/vegan-banner.jpg" alt="Recipe Box Logo" class="fill" style="height: 75%; width: 100%;">
        </div>
      </div>
    </div>
    <div class="col-md-5">
      <img src="/img/mockup-box.png" alt="Recipe Box Logo" class="fill" style="height: 75%; width: 100%;">
      <p class="lead fw-normal text-dark-30 mb-0">Recipe Box is a new and exciting website that is perfect for anyone who wants to order food quickly and easily. 
        This website offers a wide variety of delicious recipes from around the world, making it easy for users to find something that they will love. 
        Whether you're looking for a quick and easy dinner or a more elaborate meal, Recipe Box has something for everyone.</p>
    </div>
  </div>
</div>



</body>


<?php
$productController = new ProductController();

$products = $productController->getMostRecentFive();
echo "aaaaaaaaaaaaaaaaaaaaaa";

$name = $products[0]->getProductName();
$image = $products[0]->getImageAddress();
?>

<!-- Render the card using the recipe data -->
<div class="card" style="width: 18rem;">
	<img src="<?php echo $image; ?>" class="card-img-top" alt="<?php echo $name; ?>">
	<div class="card-body">
		<h5 class="card-title"><?php echo $name; ?></h5>
		<p class="card-text"><?php echo "aa"; ?></p>
		<a href="<?php echo "aa"; ?>" class="btn btn-primary">View Recipe</a>
	</div>
</div>
<?php
include __DIR__ . '/../footer.php';
?>